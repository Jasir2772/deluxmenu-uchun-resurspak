# ExezVisual 1.1 (Fabric 1.21.1, faqat klient, faqat vizual)

Menyu: RIGHT SHIFT (telefonda launcher boshqaruv tugmasiga biriktir). Zoom: C.
Menyu > HUD > "HUD joylash": elementlarni barmoq bilan sudrab joylashtirasan.

## Telefonda yig'ish (GitHub orqali)
1. github.com da yangi repo och, shu papkadagi hamma fayllarni (`.github` bilan) yukla.
2. Actions > "build" (3-5 daqiqa).
3. Artifacts > ExezVisual-jar > `ExezVisual-1.1.0.jar` ni mods papkasiga sol.
Kerak: Fabric Loader + Fabric API (1.21.1), Java 21.
