package uz.exezvisual;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class ConfigScreen extends Screen {
    private static final String[] TABS = {"HUD", "Elementlar", "PvP", "FPS"};
    private static int tab = 0;
    private final Screen parent;
    private int n;
    private static final int W = 150, H = 20, GAP = 3;

    public ConfigScreen(Screen parent) {
        super(Text.literal("ExezVisual"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        n = 0;
        Config c = Config.I;
        int tw = 74, tx = width / 2 - (TABS.length * tw) / 2;
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            addDrawableChild(ButtonWidget.builder(Text.literal((i == tab ? "\u00a7e" : "") + TABS[i]), b -> { tab = idx; clearAndInit(); })
                    .dimensions(tx + i * tw, 8, tw - 2, 18).build());
        }

        switch (tab) {
            case 0 -> {
                toggle("HUD", () -> c.hud, v -> c.hud = v);
                toggle("FPS", () -> c.showFps, v -> c.showFps = v);
                toggle("CPS", () -> c.showCps, v -> c.showCps = v);
                toggle("Ping", () -> c.showPing, v -> c.showPing = v);
                toggle("Koordinata", () -> c.showCoords, v -> c.showCoords = v);
                cycle("Aksent", () -> Config.ACCENT_NAMES[c.accentIndex], () -> c.accentIndex = (c.accentIndex + 1) % Config.ACCENTS.length);
                button("HUD joylash", () -> client.setScreen(new HudEditorScreen(this)));
            }
            case 1 -> {
                toggle("Tugmalar", () -> c.showKeys, v -> c.showKeys = v);
                toggle("Zirh", () -> c.armorHud, v -> c.armorHud = v);
                toggle("Totem soni", () -> c.totemCounter, v -> c.totemCounter = v);
                toggle("Potion", () -> c.potionHud, v -> c.potionHud = v);
                toggle("Cooldown", () -> c.cooldownsHud, v -> c.cooldownsHud = v);
                toggle("Inventar", () -> c.inventoryHud, v -> c.inventoryHud = v);
                toggle("To'qlik", () -> c.saturationHud, v -> c.saturationHud = v);
                toggle("Watermark", () -> c.watermark, v -> c.watermark = v);
            }
            case 2 -> {
                toggle("Target HUD", () -> c.targetHud, v -> c.targetHud = v);
                toggle("Kombo", () -> c.comboHud, v -> c.comboHud = v);
                toggle("Hit rang", () -> c.hitColor, v -> { c.hitColor = v; ExezVisualClient.applyHitColor(client); });
                cycle("Rang", () -> Config.HIT_NAMES[c.hitColorIndex], () -> { c.hitColorIndex = (c.hitColorIndex + 1) % Config.HIT_COLORS.length; ExezVisualClient.applyHitColor(client); });
                toggle("Hit ovozi", () -> c.hitSound, v -> c.hitSound = v);
                toggle("Silliq zoom", () -> c.zoomSmooth, v -> c.zoomSmooth = v);
                cycle("Crosshair", () -> Config.CROSSHAIRS[c.crosshairStyle], () -> c.crosshairStyle = (c.crosshairStyle + 1) % Config.CROSSHAIRS.length);
                toggle("Crosshair aksent", () -> c.crosshairAccent, v -> c.crosshairAccent = v);
                toggle("Hurt cam o'chir", () -> c.noHurtCam, v -> c.noHurtCam = v);
            }
            default -> {
                toggle("Fullbright", () -> c.fullbright, v -> c.fullbright = v);
                toggle("Past olov", () -> c.lowFire, v -> c.lowFire = v);
                toggle("Vignette o'chir", () -> c.noVignette, v -> c.noVignette = v);
                toggle("Yomg'ir/qor o'chir", () -> c.noWeather, v -> c.noWeather = v);
                cycle("Zarralar", () -> Config.PARTICLES[c.particleMode], () -> c.particleMode = (c.particleMode + 1) % 3);
                toggle("Entity cull", () -> c.entityCull, v -> c.entityCull = v);
                cycle("Cull masofa", () -> c.cullDist() + " blok", () -> c.cullIndex = (c.cullIndex + 1) % Config.CULL_DIST.length);
            }
        }

        addDrawableChild(ButtonWidget.builder(Text.literal("Tayyor"), b -> close())
                .dimensions(width / 2 - 60, height - 24, 120, 18).build());
    }

    private int sx() { return n % 2 == 0 ? width / 2 - W - GAP / 2 : width / 2 + GAP / 2; }
    private int sy() { return 34 + (n / 2) * (H + GAP); }

    private void toggle(String name, BooleanSupplier get, Consumer<Boolean> set) {
        addDrawableChild(ButtonWidget.builder(label(name, get.getAsBoolean()), b -> {
            boolean v = !get.getAsBoolean();
            set.accept(v);
            b.setMessage(label(name, v));
        }).dimensions(sx(), sy(), W, H).build());
        n++;
    }

    private void cycle(String name, Supplier<String> val, Runnable next) {
        addDrawableChild(ButtonWidget.builder(Text.literal(name + ": " + val.get()), b -> {
            next.run();
            b.setMessage(Text.literal(name + ": " + val.get()));
        }).dimensions(sx(), sy(), W, H).build());
        n++;
    }

    private void button(String name, Runnable r) {
        addDrawableChild(ButtonWidget.builder(Text.literal(name), b -> r.run()).dimensions(sx(), sy(), W, H).build());
        n++;
    }

    private static Text label(String n, boolean on) {
        return Text.literal(n + ": " + (on ? "\u00a7aON" : "\u00a7cOFF"));
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        renderBackground(ctx, mx, my, delta);
        super.render(ctx, mx, my, delta);
    }

    @Override
    public void close() {
        Config.save();
        client.setScreen(parent);
    }
}
