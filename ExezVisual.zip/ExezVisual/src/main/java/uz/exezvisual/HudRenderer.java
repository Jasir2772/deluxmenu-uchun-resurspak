package uz.exezvisual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.BooleanSupplier;

public final class HudRenderer {
    public static final int BG = 0x90101018;

    public interface Painter {
        void paint(DrawContext ctx, MinecraftClient mc, TextRenderer tr, int x, int y, Element e);
    }

    public static final class Element {
        public final String id, name;
        public final BooleanSupplier on;
        public final BiFunction<Integer, Integer, int[]> def;
        final Painter painter;
        public int w, h;
        public boolean visible;

        Element(String id, String name, BooleanSupplier on, BiFunction<Integer, Integer, int[]> def, int w, int h, Painter p) {
            this.id = id; this.name = name; this.on = on; this.def = def; this.w = w; this.h = h; this.painter = p;
        }
        void done(int w, int h) { this.w = w; this.h = h; this.visible = true; }
    }

    public static final List<Element> ELEMENTS = new ArrayList<>();

    private static void add(String id, String name, BooleanSupplier on, BiFunction<Integer, Integer, int[]> def, int w, int h, Painter p) {
        ELEMENTS.add(new Element(id, name, on, def, w, h, p));
    }

    static {
        add("watermark", "Watermark", () -> Config.I.watermark, (sw, sh) -> new int[]{sw - 80, 6}, 74, 16, HudRenderer::watermark);
        add("info", "Info", () -> Config.I.showFps || Config.I.showCps || Config.I.showPing, (sw, sh) -> new int[]{6, 6}, 120, 18, HudRenderer::info);
        add("coords", "Koordinata", () -> Config.I.showCoords, (sw, sh) -> new int[]{6, 27}, 110, 18, HudRenderer::coords);
        add("keys", "Tugmalar", () -> Config.I.showKeys, (sw, sh) -> new int[]{6, 50}, 60, 58, HudRenderer::keys);
        add("cooldowns", "Cooldown", () -> Config.I.cooldownsHud, (sw, sh) -> new int[]{6, 114}, 76, 26, HudRenderer::cooldowns);
        add("potions", "Potion", () -> Config.I.potionHud, (sw, sh) -> new int[]{6, 144}, 100, 20, HudRenderer::potions);
        add("armor", "Zirh", () -> Config.I.armorHud, (sw, sh) -> new int[]{sw - 66, sh / 2 - 38}, 60, 76, HudRenderer::armor);
        add("totem", "Totem", () -> Config.I.totemCounter, (sw, sh) -> new int[]{sw - 46, sh - 24}, 40, 18, HudRenderer::totem);
        add("saturation", "To'qlik", () -> Config.I.saturationHud, (sw, sh) -> new int[]{sw / 2 - 91, sh - 62}, 80, 14, HudRenderer::saturation);
        add("target", "Target", () -> Config.I.targetHud, (sw, sh) -> new int[]{sw / 2 - 65, sh / 2 + 26}, 130, 30, HudRenderer::target);
        add("combo", "Kombo", () -> Config.I.comboHud, (sw, sh) -> new int[]{sw / 2 - 30, sh / 2 + 62}, 60, 16, HudRenderer::combo);
        add("inventory", "Inventar", () -> Config.I.inventoryHud, (sw, sh) -> new int[]{sw / 2 - 85, 30}, 170, 62, HudRenderer::inventory);
    }

    // ---- keshlangan matnlar (har 250 ms): CPU va GC tejaladi ----
    private static long lastBuild = 0;
    private static String infoText = "", coordText = "", targetHp = "";
    private static final String[] potLines = new String[6];
    private static final int[] potColors = new int[6];
    private static int potCount, potW;
    private static int lastCombo = -1;
    private static String comboStr = "";

    public static int[] pos(Element e, int sw, int sh) {
        int[] p = Config.I.pos.get(e.id);
        if (p == null || p.length < 2) p = e.def.apply(sw, sh);
        return p;
    }

    public static void render(DrawContext ctx, RenderTickCounter counter) {
        Config c = Config.I;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!c.hud || mc.player == null || mc.options.hudHidden || mc.getDebugHud().shouldShowDebugHud()) return;
        TextRenderer tr = mc.textRenderer;
        refresh(mc, tr);
        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        for (int i = 0; i < ELEMENTS.size(); i++) {
            Element e = ELEMENTS.get(i);
            e.visible = false;
            if (!e.on.getAsBoolean()) continue;
            int[] p = pos(e, sw, sh);
            int x = Math.max(0, Math.min(p[0], sw - e.w));
            int y = Math.max(0, Math.min(p[1], sh - e.h));
            e.painter.paint(ctx, mc, tr, x, y, e);
        }
        crosshair(ctx, mc, sw, sh);
    }

    private static void refresh(MinecraftClient mc, TextRenderer tr) {
        long now = System.currentTimeMillis();
        if (now - lastBuild < 250) return;
        lastBuild = now;
        Config c = Config.I;

        StringBuilder sb = new StringBuilder();
        if (c.showFps) sb.append("FPS ").append(mc.getCurrentFps());
        if (c.showCps) { if (sb.length() > 0) sb.append("  \u2022  "); sb.append("CPS ").append(Cps.get()); }
        if (c.showPing) {
            PlayerListEntry e = mc.getNetworkHandler() == null ? null : mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            if (sb.length() > 0) sb.append("  \u2022  ");
            sb.append(e == null ? "-- ms" : e.getLatency() + " ms");
        }
        infoText = sb.toString();

        BlockPos bp = mc.player.getBlockPos();
        coordText = bp.getX() + " " + bp.getY() + " " + bp.getZ() + "  " + mc.player.getHorizontalFacing().name().charAt(0);

        potCount = 0; potW = 0;
        for (StatusEffectInstance e : mc.player.getStatusEffects()) {
            if (potCount >= potLines.length) break;
            String name = e.getEffectType().value().getName().getString();
            if (e.getAmplifier() > 0) name += " " + (e.getAmplifier() + 1);
            String t;
            if (e.isInfinite()) t = "inf";
            else { int s = e.getDuration() / 20; t = (s / 60) + ":" + (s % 60 < 10 ? "0" : "") + (s % 60); }
            String line = name + "  " + t;
            potLines[potCount] = line;
            potColors[potCount] = 0xFF000000 | e.getEffectType().value().getColor();
            potW = Math.max(potW, tr.getWidth(line));
            potCount++;
        }

        LivingEntity t = Combat.target;
        targetHp = t == null ? "" : Float.toString(Math.round(t.getHealth() * 10f) / 10f);
    }

    // ---------------- elementlar ----------------
    private static void watermark(DrawContext ctx, MinecraftClient mc, TextRenderer tr, int x, int y, Element e) {
        panel(ctx, x, y, 74, 16, Config.I.accent());
        ctx.drawText(tr, "ExezVisual", x + 7, y + 4, 0xFFFFFFFF, false);
        e.done(74, 16);
    }

    private static void info(DrawContext ctx, MinecraftClient mc, TextRenderer tr, int x, int y, Element e) {
        if (infoText.isEmpty()) return;
        int w = tr.getWidth(infoText) + 12;
        panel(ctx, x, y, w, 18, Config.I.accent());
        ctx.drawText(tr, infoText, x + 6, y + 5, 0xFFFFFFFF, false);
        e.done(w, 18);
    }

    private static void coords(DrawContext ctx, MinecraftClient mc, TextRenderer tr, int x, int y, Element e) {
        int w = tr.getWidth(coordText) + 12;
        panel(ctx, x, y, w, 18, Config.I.accent());
        ctx.drawText(tr, coordText, x + 6, y + 5, 0xFFFFFFFF, false);
        e.done(w, 18);
    }

    private static void keys(DrawContext ctx, MinecraftClient mc, TextRenderer tr, int x, int y, Element e) {
        var o = mc.options;
        int a = Config.I.accent();
        key(ctx, tr, x + 20, y, 18, 18, "W", o.forwardKey.isPressed(), a);
        key(ctx, tr, x, y + 20, 18, 18, "A", o.leftKey.isPressed(), a);
        key(ctx, tr, x + 20, y + 20, 18, 18, "S", o.backKey.isPressed(), a);
        key(ctx, tr, x + 40, y + 20, 18, 18, "D", o.rightKey.isPressed(), a);
        key(ctx, tr, x, y + 40, 29, 18, "LMB", o.attackKey.isPressed(), a);
        key(ctx, tr, x + 31, y + 40, 29, 18, "RMB", o.useKey.isPressed(), a);
        e.done(60, 58);
    }

    private static void key(DrawContext ctx, TextRenderer tr, int x, int y, int w, int h, String s, boolean down, int accent) {
        int bg = down ? ((accent & 0x00FFFFFF) | 0xC0000000) : BG;
        ctx.fill(x, y, x + w, y + h, bg);
        ctx.drawText(tr, s, x + (w - tr.getWidth(s)) / 2, y + (h - 8) / 2, 0xFFFFFFFF, false);
    }

    private static final Item[] CD_ITEMS = {Items.ENDER_PEARL, Items.GOLDEN_APPLE, Items.ENCHANTED_GOLDEN_APPLE, Items.CHORUS_FRUIT, Items.SHIELD};
    private static ItemStack[] cdStacks;
    private static final float[] cdProg = new float[CD_ITEMS.length];

    private static void cooldowns(DrawContext ctx, MinecraftClient mc, TextRenderer tr, int x, int y, Element e) {
        if (cdStacks == null) {
            cdStacks = new ItemStack[CD_ITEMS.length];
            for (int i = 0; i < CD_ITEMS.length; i++) cdStacks[i] = new ItemStack(CD_ITEMS[i]);
        }
        var mgr = mc.player.getItemCooldownManager();
        int n = 0;
        for (int i = 0; i < CD_ITEMS.length; i++) { cdProg[i] = mgr.getCooldownProgress(CD_ITEMS[i], 0f); if (cdProg[i] > 0f) n++; }
        if (n == 0) return;
        int a = Config.I.accent();
        panel(ctx, x, y, 76, 8 + n * 18, a);
        int row = 0;
        for (int i = 0; i < CD_ITEMS.length; i++) {
            if (cdProg[i] <= 0f) continue;
            int yy = y + 4 + row * 18;
            ctx.drawItem(cdStacks[i], x + 4, yy);
            ctx.fill(x + 24, yy + 6, x + 70, yy + 10, 0xFF2A2A35);
            ctx.fill(x + 24, yy + 6, x + 24 + (int) (46 * cdProg[i]), yy + 10, a);
            row++;
        }
        e.done(76, 8 + n * 18);
    }

    private static void potions(DrawContext ctx, MinecraftClient mc, TextRenderer tr, int x, int y, Element e) {
        if (potCount == 0) return;
        int w = potW + 20, h = 8 + potCount * 12;
        panel(ctx, x, y, w, h, Config.I.accent());
        for (int i = 0; i < potCount; i++) {
            int yy = y + 5 + i * 12;
            ctx.fill(x + 6, yy + 2, x + 10, yy + 6, potColors[i]);
            ctx.drawText(tr, potLines[i], x + 14, yy, 0xFFFFFFFF, false);
        }
        e.done(w, h);
    }

    private static void armor(DrawContext ctx, MinecraftClient mc, TextRenderer tr, int x, int y, Element e) {
        panel(ctx, x, y, 60, 76, Config.I.accent());
        for (int i = 0; i < 4; i++) {
            ItemStack s = mc.player.getInventory().getArmorStack(3 - i);
            if (s.isEmpty()) continue;
            int yy = y + 4 + i * 18;
            ctx.drawItem(s, x + 4, yy);
            if (s.isDamageable()) {
                int left = s.getMaxDamage() - s.getDamage();
                float p = left / (float) s.getMaxDamage();
                int col = p > 0.5f ? 0xFF55FF77 : p > 0.2f ? 0xFFFFC043 : 0xFFFF4D4D;
                ctx.drawText(tr, Integer.toString(left), x + 24, yy + 4, col, false);
            }
        }
        e.done(60, 76);
    }

    private static ItemStack totemStack;

    private static void totem(DrawContext ctx, MinecraftClient mc, TextRenderer tr, int x, int y, Element e) {
        if (totemStack == null) totemStack = new ItemStack(Items.TOTEM_OF_UNDYING);
        panel(ctx, x, y, 40, 18, Config.I.accent());
        ctx.drawItem(totemStack, x + 2, y + 1);
        int n = ExezVisualClient.totems;
        ctx.drawText(tr, "x" + n, x + 21, y + 5, n == 0 ? 0xFFFF4D4D : 0xFFFFFFFF, false);
        e.done(40, 18);
    }

    private static void saturation(DrawContext ctx, MinecraftClient mc, TextRenderer tr, int x, int y, Element e) {
        var hm = mc.player.getHungerManager();
        String s = "Sat " + Math.round(hm.getSaturationLevel());
        int w = tr.getWidth(s) + 10;
        ctx.fill(x, y, x + w, y + 14, BG);
        ctx.drawText(tr, s, x + 5, y + 3, 0xFFFFD27A, false);
        e.done(w, 14);
    }

    private static void target(DrawContext ctx, MinecraftClient mc, TextRenderer tr, int x, int y, Element e) {
        LivingEntity t = Combat.target;
        if (t == null) return;
        float max = Math.max(1f, t.getMaxHealth());
        Combat.shownHp += (t.getHealth() - Combat.shownHp) * 0.2f;
        float r = Math.max(0f, Math.min(1f, Combat.shownHp / max));
        int col = r > 0.5f ? 0xFF55FF77 : r > 0.25f ? 0xFFFFC043 : 0xFFFF4D4D;
        panel(ctx, x, y, 130, 30, Config.I.accent());
        ctx.drawText(tr, t.getName(), x + 6, y + 6, 0xFFFFFFFF, false);
        ctx.drawText(tr, targetHp, x + 124 - tr.getWidth(targetHp), y + 6, col, false);
        ctx.fill(x + 6, y + 19, x + 124, y + 25, 0xFF2A2A35);
        ctx.fill(x + 6, y + 19, x + 6 + (int) (118 * r), y + 25, col);
        e.done(130, 30);
    }

    private static void combo(DrawContext ctx, MinecraftClient mc, TextRenderer tr, int x, int y, Element e) {
        int n = Combat.combo;
        if (n <= 0) return;
        if (n != lastCombo) { lastCombo = n; comboStr = "Combo x" + n; }
        int w = tr.getWidth(comboStr) + 12;
        panel(ctx, x, y, w, 16, Config.I.accent());
        ctx.drawText(tr, comboStr, x + 6, y + 4, 0xFFFFFFFF, false);
        e.done(w, 16);
    }

    private static void inventory(DrawContext ctx, MinecraftClient mc, TextRenderer tr, int x, int y, Element e) {
        panel(ctx, x, y, 170, 62, Config.I.accent());
        var inv = mc.player.getInventory().main;
        for (int i = 0; i < 27; i++) {
            ItemStack s = inv.get(9 + i);
            if (s.isEmpty()) continue;
            int ix = x + 4 + (i % 9) * 18, iy = y + 4 + (i / 9) * 18;
            ctx.drawItem(s, ix, iy);
            ctx.drawStackOverlay(tr, s, ix, iy);
        }
        e.done(170, 62);
    }

    private static void crosshair(DrawContext ctx, MinecraftClient mc, int sw, int sh) {
        int st = Config.I.crosshairStyle;
        if (st == 0 || mc.currentScreen != null || !mc.options.getPerspective().isFirstPerson()) return;
        int cx = sw / 2, cy = sh / 2;
        int col = Config.I.crosshairAccent ? Config.I.accent() : 0xFFFFFFFF;
        switch (st) {
            case 1 -> ctx.fill(cx - 1, cy - 1, cx + 1, cy + 1, col);
            case 2 -> {
                ctx.fill(cx - 5, cy, cx + 6, cy + 1, col);
                ctx.fill(cx, cy - 5, cx + 1, cy + 6, col);
            }
            default -> {
                ctx.fill(cx - 8, cy, cx - 3, cy + 1, col);
                ctx.fill(cx + 4, cy, cx + 9, cy + 1, col);
                ctx.fill(cx, cy - 8, cx + 1, cy - 3, col);
                ctx.fill(cx, cy + 4, cx + 1, cy + 9, col);
            }
        }
    }

    /** Arzon yumaloq panel: shader/teksturasiz (telefon uchun optimal). */
    public static void panel(DrawContext ctx, int x, int y, int w, int h, int accent) {
        ctx.fill(x + 1, y, x + w - 1, y + h, BG);
        ctx.fill(x, y + 1, x + w, y + h - 1, BG);
        ctx.fill(x + 2, y, x + w - 2, y + 1, accent);
    }
}
