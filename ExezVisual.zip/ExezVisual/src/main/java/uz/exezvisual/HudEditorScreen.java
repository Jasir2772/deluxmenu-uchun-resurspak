package uz.exezvisual;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.List;

public class HudEditorScreen extends Screen {
    private final Screen parent;
    private HudRenderer.Element drag;
    private int offX, offY;

    public HudEditorScreen(Screen parent) {
        super(Text.literal("HUD joylash"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        addDrawableChild(ButtonWidget.builder(Text.literal("Tayyor"), b -> close())
                .dimensions(width / 2 - 62, height - 24, 60, 18).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Qayta tiklash"), b -> Config.I.pos.clear())
                .dimensions(width / 2 + 2, height - 24, 60, 18).build());
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        renderBackground(ctx, mx, my, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, "Elementni barmoq bilan sudrab joylashtir", width / 2, 8, 0xFFFFFFFF);
        for (HudRenderer.Element e : HudRenderer.ELEMENTS) {
            if (!e.on.getAsBoolean()) continue;
            int[] p = HudRenderer.pos(e, width, height);
            int x = Math.max(0, Math.min(p[0], width - e.w)), y = Math.max(0, Math.min(p[1], height - e.h));
            ctx.fill(x, y, x + e.w, y + e.h, e == drag ? 0x60FFFFFF : 0x40FFFFFF);
            ctx.drawBorder(x, y, e.w, e.h, Config.I.accent());
            ctx.drawText(textRenderer, e.name, x + 3, y + 3, 0xFFFFFFFF, false);
        }
        super.render(ctx, mx, my, delta);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) return true;
        List<HudRenderer.Element> l = HudRenderer.ELEMENTS;
        for (int i = l.size() - 1; i >= 0; i--) {
            HudRenderer.Element e = l.get(i);
            if (!e.on.getAsBoolean()) continue;
            int[] p = HudRenderer.pos(e, width, height);
            int x = Math.max(0, Math.min(p[0], width - e.w)), y = Math.max(0, Math.min(p[1], height - e.h));
            if (mx >= x && mx <= x + e.w && my >= y && my <= y + e.h) {
                drag = e; offX = (int) mx - x; offY = (int) my - y;
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (drag != null) {
            int nx = Math.max(0, Math.min(((int) mx - offX) / 2 * 2, width - drag.w));
            int ny = Math.max(0, Math.min(((int) my - offY) / 2 * 2, height - drag.h));
            Config.I.pos.put(drag.id, new int[]{nx, ny});
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        drag = null;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public void close() {
        Config.save();
        client.setScreen(parent);
    }
}
