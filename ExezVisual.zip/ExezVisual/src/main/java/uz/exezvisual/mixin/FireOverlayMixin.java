package uz.exezvisual.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import uz.exezvisual.Config;

@Mixin(InGameOverlayRenderer.class)
public class FireOverlayMixin {
    @Inject(method = "renderFireOverlay", at = @At("HEAD"))
    private static void exez$fireIn(MinecraftClient client, MatrixStack matrices, CallbackInfo ci) {
        matrices.push();
        if (Config.I.lowFire) matrices.translate(0.0F, -0.35F, 0.0F);
    }

    @Inject(method = "renderFireOverlay", at = @At("RETURN"))
    private static void exez$fireOut(MinecraftClient client, MatrixStack matrices, CallbackInfo ci) {
        matrices.pop();
    }
}
