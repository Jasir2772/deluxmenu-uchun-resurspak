package uz.exezvisual.mixin;

import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import uz.exezvisual.Config;

@Mixin(GameRenderer.class)
public class HurtCamMixin {
    @Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true)
    private void exez$noHurtCam(MatrixStack matrices, float tickDelta, CallbackInfo ci) {
        if (Config.I.noHurtCam) ci.cancel();
    }
}
