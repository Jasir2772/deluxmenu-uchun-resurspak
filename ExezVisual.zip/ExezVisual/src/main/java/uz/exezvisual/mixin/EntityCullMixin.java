package uz.exezvisual.mixin;

import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import uz.exezvisual.Config;

@Mixin(EntityRenderDispatcher.class)
public class EntityCullMixin {
    /** Uzoqdagi kichik entitylarni (mob, item, o'q) chizmaydi: kalta FPS oshadi. O'yinchilar hech qachon yashirilmaydi. */
    @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true)
    private void exez$cull(Entity entity, Frustum frustum, double x, double y, double z, CallbackInfoReturnable<Boolean> cir) {
        if (!Config.I.entityCull || entity instanceof PlayerEntity || entity.getWidth() >= 2.5f) return;
        double dx = entity.getX() - x, dy = entity.getY() - y, dz = entity.getZ() - z;
        double d = Config.I.cullDist();
        if (dx * dx + dy * dy + dz * dz > d * d) cir.setReturnValue(false);
    }
}
