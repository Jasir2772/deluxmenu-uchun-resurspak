package uz.exezvisual.mixin;

import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.particle.ParticleEffect;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import uz.exezvisual.Config;

@Mixin(ParticleManager.class)
public class ParticleMixin {
    private static int exez$counter = 0;

    @Inject(method = "addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)Lnet/minecraft/client/particle/Particle;",
            at = @At("HEAD"), cancellable = true)
    private void exez$limit(ParticleEffect effect, double x, double y, double z, double vx, double vy, double vz,
                            CallbackInfoReturnable<Particle> cir) {
        int m = Config.I.particleMode;
        if (m == 2 || (m == 1 && (++exez$counter & 1) == 0)) cir.setReturnValue(null);
    }
}
