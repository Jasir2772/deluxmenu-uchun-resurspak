package uz.exezvisual.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import uz.exezvisual.Combat;
import uz.exezvisual.Cps;

@Mixin(MinecraftClient.class)
public class MinecraftClientMixin {
    @Inject(method = "doAttack", at = @At("HEAD"))
    private void exez$onAttack(CallbackInfoReturnable<Boolean> cir) {
        Cps.click();
        MinecraftClient mc = (MinecraftClient) (Object) this;
        if (mc.player != null && mc.targetedEntity instanceof LivingEntity le) Combat.hit(mc, le);
    }
}
