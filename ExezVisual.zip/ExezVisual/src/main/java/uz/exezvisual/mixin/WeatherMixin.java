package uz.exezvisual.mixin;

import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.WorldRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import uz.exezvisual.Config;

@Mixin(WorldRenderer.class)
public class WeatherMixin {
    @Inject(method = "renderWeather", at = @At("HEAD"), cancellable = true)
    private void exez$noWeather(LightmapTextureManager manager, float tickDelta, double cx, double cy, double cz, CallbackInfo ci) {
        if (Config.I.noWeather) ci.cancel();
    }
}
