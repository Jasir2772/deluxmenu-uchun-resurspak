package uz.exezvisual.mixin;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import uz.exezvisual.Config;

@Mixin(InGameHud.class)
public class VignetteMixin {
    @Inject(method = "renderVignetteOverlay", at = @At("HEAD"), cancellable = true)
    private void exez$noVignette(DrawContext context, Entity entity, CallbackInfo ci) {
        if (Config.I.noVignette) ci.cancel();
    }
}
