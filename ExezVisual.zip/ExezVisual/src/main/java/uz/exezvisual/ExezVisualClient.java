package uz.exezvisual;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import org.lwjgl.glfw.GLFW;
import uz.exezvisual.mixin.OverlayTextureAccessor;

public class ExezVisualClient implements ClientModInitializer {
    public static KeyBinding openMenu, zoomKey;
    public static float zoom = 0f;
    public static int totems = 0;
    private static int appliedHitColor = -1;
    private static int tick = 0;

    @Override
    public void onInitializeClient() {
        Config.load();
        openMenu = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.exezvisual.menu", GLFW.GLFW_KEY_RIGHT_SHIFT, "category.exezvisual"));
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.exezvisual.zoom", GLFW.GLFW_KEY_C, "category.exezvisual"));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openMenu.wasPressed()) mc.setScreen(new ConfigScreen(mc.currentScreen));

            float target = zoomKey.isPressed() ? 1f : 0f;
            zoom = Config.I.zoomSmooth ? zoom + (target - zoom) * 0.35f : target;

            Combat.tick(mc);
            if (mc.player == null) return;
            if ((++tick & 15) == 0) {
                int n = 0;
                for (ItemStack s : mc.player.getInventory().main) if (s.isOf(Items.TOTEM_OF_UNDYING)) n += s.getCount();
                ItemStack off = mc.player.getOffHandStack();
                if (off.isOf(Items.TOTEM_OF_UNDYING)) n += off.getCount();
                totems = n;
                applyHitColor(mc);
            }
        });

        HudRenderCallback.EVENT.register(HudRenderer::render);
    }

    /** Zarba rangi: overlay teksturadagi "hurt" qatorlarni qayta bo'yaydi (faqat vizual). */
    public static void applyHitColor(MinecraftClient mc) {
        if (mc == null || mc.gameRenderer == null) return;
        Config c = Config.I;
        int want = c.hitColor ? c.hitColor() : 0xFF0000;
        if (want == appliedHitColor) return;
        NativeImageBackedTexture tex = ((OverlayTextureAccessor) mc.gameRenderer.getOverlayTexture()).exez$getTexture();
        NativeImage img = tex.getImage();
        if (img == null) return;
        int abgr = (178 << 24) | ((want & 0xFF) << 16) | (((want >> 8) & 0xFF) << 8) | ((want >> 16) & 0xFF);
        for (int y = 0; y < 8; y++) for (int x = 0; x < 16; x++) img.setColor(x, y, abgr);
        tex.upload();
        appliedHitColor = want;
    }
}
