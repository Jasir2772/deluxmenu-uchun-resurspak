package uz.exezvisual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.entity.LivingEntity;
import net.minecraft.sound.SoundEvents;

public final class Combat {
    public static LivingEntity target;
    public static long lastHit;
    public static int combo;
    public static float shownHp;

    public static void hit(MinecraftClient mc, LivingEntity e) {
        if (target != e) { target = e; shownHp = e.getHealth(); }
        lastHit = System.currentTimeMillis();
        combo++;
        if (Config.I.hitSound) {
            mc.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 1.5f));
        }
    }

    public static void tick(MinecraftClient mc) {
        if (mc.player == null) { target = null; combo = 0; return; }
        long now = System.currentTimeMillis();
        if (mc.player.hurtTime > 0 || now - lastHit > 3000) combo = 0;
        if (target != null && (now - lastHit > 5000 || target.isRemoved())) target = null;
    }
}
