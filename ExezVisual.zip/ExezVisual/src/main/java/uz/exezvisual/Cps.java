package uz.exezvisual;

public final class Cps {
    private static final long[] BUF = new long[64];
    private static int head = 0;

    public static void click() {
        BUF[head = (head + 1) & 63] = System.currentTimeMillis();
    }

    public static int get() {
        long now = System.currentTimeMillis();
        int n = 0;
        for (long t : BUF) if (now - t <= 1000) n++;
        return n;
    }
}
