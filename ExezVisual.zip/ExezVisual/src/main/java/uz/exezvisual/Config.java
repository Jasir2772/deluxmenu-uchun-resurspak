package uz.exezvisual;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

public final class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("exezvisual.json");

    public static Config I = new Config();

    // HUD
    public boolean hud = true;
    public boolean showFps = true, showCps = true, showPing = true, showCoords = true;
    public boolean showKeys = true, armorHud = true, totemCounter = true, potionHud = true;
    public boolean cooldownsHud = true, inventoryHud = false, saturationHud = true, watermark = true;
    // PvP vizual
    public boolean targetHud = true, comboHud = true, hitColor = true, hitSound = true, zoomSmooth = true;
    public int hitColorIndex = 0, crosshairStyle = 0;
    public boolean crosshairAccent = true;
    public int accentIndex = 0;
    // Ko'rinish / FPS
    public boolean fullbright = false, lowFire = true, noHurtCam = false, noVignette = true, noWeather = false;
    public int particleMode = 0;           // 0 to'liq, 1 yarim, 2 o'chiq
    public boolean entityCull = true;
    public int cullIndex = 1;
    // HUD joylashuvi
    public Map<String, int[]> pos = new HashMap<>();

    public static final int[] HIT_COLORS = {0xFF3B3B, 0x3BA7FF, 0xB45CFF, 0x39FF88, 0xFFD23B};
    public static final String[] HIT_NAMES = {"Qizil", "Ko'k", "Binafsha", "Yashil", "Sariq"};
    public static final int[] ACCENTS = {0x7C5CFF, 0x00D4FF, 0xFF4D8D, 0x3DFFA2};
    public static final String[] ACCENT_NAMES = {"Binafsha", "Havorang", "Pushti", "Yashil"};
    public static final String[] CROSSHAIRS = {"Vanilla", "Nuqta", "Plyus", "Bo'shliqli"};
    public static final String[] PARTICLES = {"To'liq", "Yarim", "O'chiq"};
    public static final int[] CULL_DIST = {32, 48, 64, 96};

    public int hitColor() { return HIT_COLORS[hitColorIndex % HIT_COLORS.length]; }
    public int accent() { return 0xFF000000 | ACCENTS[accentIndex % ACCENTS.length]; }
    public int cullDist() { return CULL_DIST[cullIndex % CULL_DIST.length]; }

    public static void load() {
        try {
            if (Files.exists(FILE)) I = GSON.fromJson(Files.readString(FILE), Config.class);
            if (I == null) I = new Config();
            if (I.pos == null) I.pos = new HashMap<>();
        } catch (Exception e) {
            I = new Config();
        }
    }

    public static void save() {
        try { Files.writeString(FILE, GSON.toJson(I)); } catch (Exception ignored) {}
    }
}
